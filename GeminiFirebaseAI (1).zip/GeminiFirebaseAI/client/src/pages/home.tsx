import { useState, useEffect } from "react";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { UploadSection } from "@/components/upload-section";
import { ProcessingSection } from "@/components/processing-section";
import { ResultsSection } from "@/components/results-section";
import { ErrorSection } from "@/components/error-section";
import { HistoricalFigureCard } from "@/components/historical-figure-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { useAppView } from "@/lib/hooks";
import { processFacialFeatures } from "@/lib/face-detection";
import { generateStory } from "@/lib/gemini";
import type { HistoricalFigure, StoryGenerationResponse } from "@shared/schema";

export default function Home() {
  const [userImageFile, setUserImageFile] = useState<File | null>(null);
  const [userImageUrl, setUserImageUrl] = useState<string | null>(null);
  const [storyData, setStoryData] = useState<StoryGenerationResponse | null>(null);
  const [faceFeatures, setFaceFeatures] = useState<any | null>(null);
  
  const { 
    currentView, 
    setCurrentView, 
    errorMessage, 
    processingStep, 
    setProcessingStep,
    resetView,
    showError 
  } = useAppView();

  // Fetch historical figures
  const { data: historicalFigures = [] } = useQuery<HistoricalFigure[]>({
    queryKey: ['/api/historical-figures'],
  });

  // Handle file selection from upload component
  const handleFileSelected = async (file: File, fileUrl: string) => {
    setUserImageFile(file);
    setUserImageUrl(fileUrl);
    setCurrentView('processing');
    
    try {
      // Process the image for facial features
      console.log('Processing image for facial features...');
      const features = await processFacialFeatures(fileUrl);
      setFaceFeatures(features);
      
      console.log('Features extracted:', features);
      
      // Generate a story with a random historical figure
      console.log('Generating story...');
      const story = await generateStory(features);
      console.log('Story generated:', story);
      
      setStoryData(story);
      setCurrentView('results');
    } catch (error) {
      console.error('Processing error:', error);
      showError(error instanceof Error ? error.message : 'Failed to process image');
    }
  };

  // Handle try again action
  const handleTryAgain = () => {
    resetView();
    if (userImageUrl) {
      URL.revokeObjectURL(userImageUrl);
      setUserImageUrl(null);
    }
    setUserImageFile(null);
    setFaceFeatures(null);
    setStoryData(null);
  };

  // Handle generating a new connection with the same photo
  const handleNewConnection = async () => {
    if (!userImageUrl || !faceFeatures) {
      return;
    }
    
    setCurrentView('processing');
    setProcessingStep(2); // Skip to "Searching historical database" step
    
    try {
      // Generate a new story with a random historical figure
      const story = await generateStory(faceFeatures);
      setStoryData(story);
      setCurrentView('results');
    } catch (error) {
      console.error('Error generating new connection:', error);
      showError('Failed to generate a new connection');
    }
  };

  // Scroll to app container when clicking "Try It Now" from hero
  const scrollToApp = () => {
    const appContainer = document.getElementById('app-container');
    if (appContainer) {
      appContainer.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Hero Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto max-w-6xl px-4 md:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-[#1d1d1f] leading-tight mb-6">
              Connect with History Through AI
            </h1>
            <p className="text-xl text-[#86868b] mb-8">
              Upload your photo and discover your historical connections. TimeTales uses advanced AI to find your historical doppelgänger and create a personalized story.
            </p>
            <Button onClick={scrollToApp} className="apple-button text-lg px-8 py-4 mb-8">
              Try It Now
            </Button>
            <div className="flex flex-wrap justify-center gap-4 md:gap-8">
              <div className="flex items-center">
                <i className="fas fa-camera text-[#0071e3] mr-2"></i>
                <span className="text-[#86868b]">Upload photo</span>
              </div>
              <div className="flex items-center">
                <i className="fas fa-magic text-[#0071e3] mr-2"></i>
                <span className="text-[#86868b]">AI processing</span>
              </div>
              <div className="flex items-center">
                <i className="fas fa-book-open text-[#0071e3] mr-2"></i>
                <span className="text-[#86868b]">Get your story</span>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Main App Section */}
      <section className="py-8 md:py-16" id="app-container">
        <div className="container mx-auto max-w-6xl px-4 md:px-8">
          <Card className="apple-card max-w-4xl mx-auto">
            {currentView === 'upload' && (
              <UploadSection onFileSelected={handleFileSelected} />
            )}
            
            {currentView === 'processing' && (
              <ProcessingSection 
                processingStep={processingStep} 
                setProcessingStep={setProcessingStep} 
              />
            )}
            
            {currentView === 'results' && storyData && userImageUrl && (
              <ResultsSection 
                userImageUrl={userImageUrl}
                storyData={storyData}
                onTryAnotherPhoto={handleTryAgain}
                onNewConnection={handleNewConnection}
              />
            )}
            
            {currentView === 'error' && (
              <ErrorSection 
                errorMessage={errorMessage} 
                onTryAgain={handleTryAgain} 
              />
            )}
          </Card>
        </div>
      </section>
      
      {/* Historical Figures Section */}
      <section className="py-16 bg-white" id="historical-figures">
        <div className="container mx-auto max-w-6xl px-4 md:px-8">
          <h2 className="text-3xl font-bold text-[#1d1d1f] text-center mb-4">Historical Connections</h2>
          <p className="text-[#86868b] text-center max-w-2xl mx-auto mb-12">
            Discover the diverse historical figures our AI can connect you with, spanning different eras, cultures, and fields of expertise.
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {historicalFigures.slice(0, 8).map((figure) => (
              <HistoricalFigureCard key={figure.id} figure={figure} />
            ))}
          </div>
          
          {historicalFigures.length > 8 && (
            <div className="text-center mt-12">
              <Button className="bg-transparent text-[#0071e3] hover:text-[#0077ed] transition-colors duration-200 font-medium">
                View All Historical Figures
                <i className="fas fa-chevron-right ml-2 text-xs"></i>
              </Button>
            </div>
          )}
        </div>
      </section>
      
      {/* How It Works Section */}
      <section className="py-16 bg-[#f5f5f7]" id="how-it-works">
        <div className="container mx-auto max-w-6xl px-4 md:px-8">
          <h2 className="text-3xl font-bold text-[#1d1d1f] text-center mb-4">How TimeTales Works</h2>
          <p className="text-[#86868b] text-center max-w-2xl mx-auto mb-12">
            Our innovative technology creates meaningful connections between you and historical figures.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="apple-card text-center">
              <div className="w-16 h-16 bg-[#0071e3]/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-camera text-[#0071e3] text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-[#1d1d1f] mb-3">Face Detection</h3>
              <p className="text-[#86868b]">
                Our advanced AI analyzes your facial features using face-api.js technology to identify key characteristics.
              </p>
            </Card>
            
            <Card className="apple-card text-center">
              <div className="w-16 h-16 bg-[#0071e3]/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-brain text-[#0071e3] text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-[#1d1d1f] mb-3">AI Matching</h3>
              <p className="text-[#86868b]">
                The Gemini AI compares your features with our database of historical figures to find meaningful connections.
              </p>
            </Card>
            
            <Card className="apple-card text-center">
              <div className="w-16 h-16 bg-[#0071e3]/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-book-open text-[#0071e3] text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-[#1d1d1f] mb-3">Story Creation</h3>
              <p className="text-[#86868b]">
                Our AI generates a personalized narrative connecting you to your historical match based on shared traits and characteristics.
              </p>
            </Card>
          </div>
        </div>
      </section>
      
      {/* Testimonial Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto max-w-6xl px-4 md:px-8">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold text-[#1d1d1f] text-center mb-8">What Users Are Saying</h2>
            
            <Card className="apple-card glass-effect mb-8">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-[#0071e3]/10 flex items-center justify-center">
                  <i className="fas fa-user text-[#0071e3]"></i>
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold text-[#1d1d1f]">Sarah Johnson</h4>
                  <div className="text-amber-400 flex">
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                  </div>
                </div>
              </div>
              <p className="text-[#1d1d1f] italic">
                "I was amazed to discover my connection to Marie Curie! The story TimeTales created about our shared determination and analytical minds was incredibly thoughtful and personal."
              </p>
            </Card>
            
            <div className="flex justify-center">
              <button className="w-3 h-3 rounded-full bg-[#0071e3] mx-1"></button>
              <button className="w-3 h-3 rounded-full bg-[#86868b]/30 mx-1"></button>
              <button className="w-3 h-3 rounded-full bg-[#86868b]/30 mx-1"></button>
            </div>
          </div>
        </div>
      </section>
      
      {/* Call To Action */}
      <section className="py-16 bg-gradient-to-r from-[#0071e3] to-blue-500 text-white">
        <div className="container mx-auto max-w-6xl px-4 md:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Discover Your Historical Connection</h2>
          <p className="text-xl opacity-90 max-w-2xl mx-auto mb-8">
            Upload your photo and let our AI create a personalized story connecting you to history.
          </p>
          <Button 
            onClick={scrollToApp}
            className="bg-white text-[#0071e3] hover:bg-opacity-90 transition-colors duration-200 rounded-full px-8 py-4 font-medium"
          >
            Get Started Now
          </Button>
        </div>
      </section>
      
      <Footer />
    </div>
  );
}
