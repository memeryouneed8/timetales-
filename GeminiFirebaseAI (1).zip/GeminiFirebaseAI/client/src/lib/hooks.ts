import { useState, useCallback, useRef, DragEvent, ChangeEvent } from "react";

// Custom hook for handling file uploads with drag and drop
export function useFileUpload() {
  const [file, setFile] = useState<File | null>(null);
  const [fileUrl, setFileUrl] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = useCallback((e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    handleFiles(files);
  }, []);

  const handleFileChange = useCallback((e: ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      handleFiles(files);
    }
  }, []);

  const handleFiles = useCallback((files: FileList) => {
    if (files.length > 0) {
      const selectedFile = files[0];
      
      // Check if file is an image
      if (!selectedFile.type.startsWith('image/')) {
        alert('Please upload an image file');
        return;
      }
      
      // Check file size (max 10MB)
      if (selectedFile.size > 10 * 1024 * 1024) {
        alert('File size should not exceed 10MB');
        return;
      }
      
      setFile(selectedFile);
      setFileUrl(URL.createObjectURL(selectedFile));
    }
  }, []);

  const triggerFileInput = useCallback(() => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  }, []);

  const clearFile = useCallback(() => {
    if (fileUrl) {
      URL.revokeObjectURL(fileUrl);
    }
    setFile(null);
    setFileUrl(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }, [fileUrl]);

  return {
    file,
    fileUrl,
    isDragging,
    fileInputRef,
    handleDragOver,
    handleDragLeave,
    handleDrop,
    handleFileChange,
    triggerFileInput,
    clearFile
  };
}

// Custom hook for managing app view state
export function useAppView() {
  type ViewState = 'upload' | 'processing' | 'results' | 'error';
  const [currentView, setCurrentView] = useState<ViewState>('upload');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [processingStep, setProcessingStep] = useState<number>(0);
  
  const resetView = useCallback(() => {
    setCurrentView('upload');
    setErrorMessage('');
    setProcessingStep(0);
  }, []);
  
  const showError = useCallback((message: string) => {
    setErrorMessage(message);
    setCurrentView('error');
  }, []);
  
  return {
    currentView,
    setCurrentView,
    errorMessage,
    processingStep,
    setProcessingStep,
    resetView,
    showError
  };
}
