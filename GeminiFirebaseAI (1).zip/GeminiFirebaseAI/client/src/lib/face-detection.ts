import * as faceapi from 'face-api.js';

// Path to face-api.js models - use a reliable CDN
const MODEL_URL = 'https://unpkg.com/face-api.js@0.22.2/weights';

// Track model loading status
let modelsLoaded = false;
let modelLoadingFailed = false;

// Function to load face-api.js models
export async function loadModels() {
  if (modelsLoaded) {
    console.log('Models already loaded, skipping...');
    return true;
  }
  
  if (modelLoadingFailed) {
    console.log('Model loading previously failed, using fallback mode');
    return false;
  }
  
  try {
    console.log('Loading face-api models from:', MODEL_URL);
    await Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
      faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
      // Loading fewer models to improve chances of success
      //faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
      //faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL)
    ]);
    console.log('Face-api models loaded successfully');
    modelsLoaded = true;
    return true;
  } catch (error) {
    console.error('Error loading face-api models:', error);
    modelLoadingFailed = true;
    return false;
  }
}

// Function to detect faces in an image
export async function detectFace(imageElement: HTMLImageElement): Promise<faceapi.FaceDetection | null> {
  try {
    // Check if models are loaded
    const modelsReady = await loadModels();
    if (!modelsReady) {
      console.log('Models not available, skipping face detection');
      return null;
    }
    
    console.log('Running face detection on image:', 
      { width: imageElement.width, height: imageElement.height, 
        complete: imageElement.complete, naturalWidth: imageElement.naturalWidth });

    // Try with the TinyFaceDetector model
    const detections = await faceapi
      .detectAllFaces(imageElement, new faceapi.TinyFaceDetectorOptions({ scoreThreshold: 0.3 }))
      .withFaceLandmarks();

    console.log('Detection results:', detections);

    if (detections.length === 0) {
      console.log('No faces detected in the image');
      return null;
    }

    // Return the face with highest confidence
    return detections[0].detection;
  } catch (error) {
    console.error('Error detecting face:', error);
    return null; // Return null instead of throwing, to make the function more resilient
  }
}

// Process image and extract facial features
export async function processFacialFeatures(imageUrl: string): Promise<any> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    
    img.onload = async () => {
      console.log('Image loaded successfully:', img.width, 'x', img.height);
      try {
        // Wait a moment to ensure the image is fully loaded
        await new Promise(r => setTimeout(r, 100));
        
        const detection = await detectFace(img);
        
        if (!detection) {
          console.log('No face detected, using fallback mode');
          // Use fallback mode - generate a random area in the center of the image
          const fallbackFeatures = {
            usingFallback: true,
            imageWidth: img.width,
            imageHeight: img.height,
            center: {
              x: Math.round(img.width / 2),
              y: Math.round(img.height / 2)
            },
            approximateSize: Math.min(img.width, img.height) / 3
          };
          resolve(fallbackFeatures);
          return;
        }
        
        // Extract basic facial features
        const features = {
          box: {
            x: detection.box.x,
            y: detection.box.y,
            width: detection.box.width,
            height: detection.box.height
          },
          confidence: detection.score,
          imageWidth: img.width,
          imageHeight: img.height
        };
        
        console.log('Detected facial features:', features);
        resolve(features);
      } catch (error: unknown) {
        console.error('Error processing facial features:', error);
        
        // Fallback mode if detection fails
        console.log('Face detection failed, using fallback mode');
        const fallbackFeatures = {
          usingFallback: true,
          imageWidth: img.width,
          imageHeight: img.height,
          errorMessage: error instanceof Error ? error.message : 'Unknown error'
        };
        resolve(fallbackFeatures);
      }
    };
    
    img.onerror = (err) => {
      console.error('Failed to load image:', err);
      reject(new Error('Failed to load image'));
    };
    
    img.src = imageUrl;
  });
}
