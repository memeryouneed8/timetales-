import { apiRequest } from "./queryClient";
import type { StoryGenerationResponse, StoryGenerationRequest } from "@shared/schema";

// Function to generate a story using the backend API
export async function generateStory(
  faceFeatures: any, 
  historicalFigureId?: number
): Promise<StoryGenerationResponse> {
  try {
    const payload: StoryGenerationRequest = {
      faceFeatures,
      historicalFigureId
    };

    const response = await apiRequest('POST', '/api/generate-story', payload);
    const data = await response.json();
    return data as StoryGenerationResponse;
  } catch (error) {
    console.error('Error generating story:', error);
    throw error;
  }
}

// Share a story
export async function shareStory(storyId: number): Promise<{shareableLink: string}> {
  try {
    const response = await apiRequest('POST', `/api/stories/${storyId}/share`);
    return await response.json();
  } catch (error) {
    console.error('Error sharing story:', error);
    throw error;
  }
}
