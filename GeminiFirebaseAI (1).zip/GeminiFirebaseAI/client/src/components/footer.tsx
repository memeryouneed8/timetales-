import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-[#f5f5f7] py-12">
      <div className="container mx-auto max-w-6xl px-4 md:px-8">
        <div className="flex flex-col md:flex-row justify-between mb-8">
          <div className="mb-8 md:mb-0">
            <Link href="/" className="text-2xl font-semibold text-[#1d1d1f]">
              Time<span className="text-[#0071e3]">Tales</span>
            </Link>
            <p className="text-[#86868b] mt-4 max-w-xs">
              Connecting people with history through the power of AI and facial recognition.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
            <div>
              <h4 className="font-semibold text-[#1d1d1f] mb-4">Product</h4>
              <ul className="space-y-2">
                <li><a href="#how-it-works" className="text-[#86868b] hover:text-[#0071e3]">How It Works</a></li>
                <li><a href="#" className="text-[#86868b] hover:text-[#0071e3]">Features</a></li>
                <li><a href="#historical-figures" className="text-[#86868b] hover:text-[#0071e3]">Gallery</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-[#1d1d1f] mb-4">Company</h4>
              <ul className="space-y-2">
                <li><a href="#about" className="text-[#86868b] hover:text-[#0071e3]">About Us</a></li>
                <li><a href="#" className="text-[#86868b] hover:text-[#0071e3]">Contact</a></li>
                <li><a href="#" className="text-[#86868b] hover:text-[#0071e3]">Blog</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-[#1d1d1f] mb-4">Legal</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-[#86868b] hover:text-[#0071e3]">Privacy Policy</a></li>
                <li><a href="#" className="text-[#86868b] hover:text-[#0071e3]">Terms of Service</a></li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="border-t border-[#d2d2d7] pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-[#86868b] text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} TimeTales. All rights reserved.
          </p>
          <div className="flex space-x-4">
            <a href="#" className="text-[#86868b] hover:text-[#0071e3]" aria-label="Twitter">
              <i className="fab fa-twitter text-xl"></i>
            </a>
            <a href="#" className="text-[#86868b] hover:text-[#0071e3]" aria-label="Facebook">
              <i className="fab fa-facebook text-xl"></i>
            </a>
            <a href="#" className="text-[#86868b] hover:text-[#0071e3]" aria-label="Instagram">
              <i className="fab fa-instagram text-xl"></i>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}