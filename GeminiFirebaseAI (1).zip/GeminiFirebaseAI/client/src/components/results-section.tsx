import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Card } from "@/components/ui/card";
import { shareStory } from "@/lib/gemini";
import type { StoryGenerationResponse } from "@shared/schema";

interface ResultsSectionProps {
  userImageUrl: string;
  storyData: StoryGenerationResponse;
  onTryAnotherPhoto: () => void;
  onNewConnection: () => void;
}

export function ResultsSection({ 
  userImageUrl, 
  storyData, 
  onTryAnotherPhoto, 
  onNewConnection 
}: ResultsSectionProps) {
  const { toast } = useToast();
  const [isSharing, setIsSharing] = useState(false);
  
  const { historicalFigure, storyContent } = storyData;
  
  // Format the story content into paragraphs
  const paragraphs = storyContent.split('\n\n').filter(p => p.trim() !== '');
  
  const handleShare = async () => {
    try {
      setIsSharing(true);
      // This would use a real story ID in production
      const result = await shareStory(1);
      
      // Copy link to clipboard
      await navigator.clipboard.writeText(result.shareableLink);
      
      toast({
        title: "Link copied to clipboard",
        description: "Share your historical connection with friends!",
      });
    } catch (error) {
      toast({
        title: "Sharing failed",
        description: "Please try again later",
        variant: "destructive",
      });
    } finally {
      setIsSharing(false);
    }
  };
  
  const handleDownload = () => {
    // This would create a combined image in production
    toast({
      title: "Image downloading",
      description: "Your image will download shortly",
    });
  };
  
  const handleFavorite = () => {
    toast({
      title: "Added to favorites",
      description: "You can find this in your profile",
    });
  };
  
  return (
    <div>
      <h2 className="text-2xl font-semibold text-[#1d1d1f] mb-6">Your Historical Connection</h2>
      
      {/* Comparison Panel */}
      <div className="flex flex-col md:flex-row gap-6 mb-8">
        <div className="w-full md:w-1/2 apple-card">
          <div className="aspect-square rounded-xl overflow-hidden mb-3">
            <img 
              src={userImageUrl} 
              alt="Your photo" 
              className="w-full h-full object-cover" 
            />
          </div>
          <p className="text-center text-[#86868b]">You</p>
        </div>
        
        <div className="w-full md:w-1/2 apple-card">
          <div className="relative aspect-square rounded-xl overflow-hidden mb-3">
            <img 
              src={historicalFigure.imageUrl} 
              alt={historicalFigure.name} 
              className="w-full h-full object-cover" 
            />
            <div className="fade-overlay"></div>
            <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
              <h4 className="text-xl font-bold">{historicalFigure.name}</h4>
              <p className="text-sm opacity-90">
                {historicalFigure.yearBorn} - {historicalFigure.yearDied || 'present'}
              </p>
            </div>
          </div>
          <p className="text-center text-[#86868b]">Historical Connection</p>
        </div>
      </div>
      
      {/* Story Section */}
      <Card className="mb-8 glass-effect p-6">
        <h3 className="text-xl font-semibold text-[#1d1d1f] mb-4">Your Historical Tale</h3>
        <div className="prose max-w-none">
          {paragraphs.map((paragraph, index) => (
            <p key={index} className="text-[#1d1d1f] leading-relaxed mt-4 first:mt-0">
              {paragraph}
            </p>
          ))}
          {historicalFigure.quote && (
            <blockquote className="italic text-[#1d1d1f] border-l-4 border-[#0071e3] pl-4 mt-6">
              "{historicalFigure.quote}"
            </blockquote>
          )}
        </div>
      </Card>
      
      {/* Action Buttons */}
      <div className="flex flex-wrap gap-4 justify-between items-center">
        <div className="flex flex-wrap gap-2">
          <Button onClick={onTryAnotherPhoto} className="apple-button">
            <i className="fas fa-redo-alt mr-2"></i>
            Try Another Photo
          </Button>
          <Button onClick={onNewConnection} className="apple-button-secondary">
            <i className="fas fa-random mr-2"></i>
            New Connection
          </Button>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={handleShare} 
            disabled={isSharing}
            className="bg-transparent text-[#1d1d1f] hover:text-[#0071e3] transition-colors duration-200 p-3 rounded-full"
          >
            <i className="fas fa-share-alt text-lg"></i>
          </Button>
          <Button 
            onClick={handleDownload} 
            className="bg-transparent text-[#1d1d1f] hover:text-[#0071e3] transition-colors duration-200 p-3 rounded-full"
          >
            <i className="fas fa-download text-lg"></i>
          </Button>
          <Button 
            onClick={handleFavorite}
            className="bg-transparent text-[#1d1d1f] hover:text-[#0071e3] transition-colors duration-200 p-3 rounded-full"
          >
            <i className="far fa-heart text-lg"></i>
          </Button>
        </div>
      </div>
    </div>
  );
}
