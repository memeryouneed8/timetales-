import type { HistoricalFigure } from "@shared/schema";

interface HistoricalFigureCardProps {
  figure: HistoricalFigure;
}

export function HistoricalFigureCard({ figure }: HistoricalFigureCardProps) {
  return (
    <div className="historical-figure rounded-2xl overflow-hidden aspect-[3/4] relative shadow-lg">
      <img 
        src={figure.imageUrl} 
        alt={figure.name} 
        className="w-full h-full object-cover"
      />
      <div className="fade-overlay"></div>
      <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
        <h3 className="text-lg font-bold">{figure.name}</h3>
        <p className="text-xs opacity-90">{figure.shortDescription}</p>
      </div>
    </div>
  );
}
