import { Button } from "@/components/ui/button";

interface ErrorSectionProps {
  errorMessage: string;
  onTryAgain: () => void;
}

export function ErrorSection({ errorMessage, onTryAgain }: ErrorSectionProps) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <div className="w-16 h-16 rounded-full bg-[#ff3b30]/10 flex items-center justify-center mb-6">
        <i className="fas fa-exclamation-triangle text-[#ff3b30] text-xl"></i>
      </div>
      <h3 className="text-xl font-medium text-[#1d1d1f] mb-2">
        Unable to Process Image
      </h3>
      <p className="text-[#86868b] max-w-md mx-auto mb-6">
        {errorMessage || "We couldn't detect a face in the uploaded image. Please try again with a clear photo showing your face."}
      </p>
      <Button onClick={onTryAgain} className="apple-button">
        <i className="fas fa-redo-alt mr-2"></i>
        Try Again
      </Button>
    </div>
  );
}
