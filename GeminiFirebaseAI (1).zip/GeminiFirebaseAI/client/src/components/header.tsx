import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  Sheet, 
  SheetContent, 
  SheetTrigger,
  SheetClose
} from "@/components/ui/sheet";

export function Header() {
  const [isOpen, setIsOpen] = useState(false);
  
  const scrollToApp = () => {
    const appElement = document.getElementById("app-container");
    if (appElement) {
      appElement.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md shadow-sm">
      <div className="container mx-auto max-w-6xl px-4 md:px-8 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/" className="text-2xl font-semibold text-[#1d1d1f]">
            Time<span className="text-[#0071e3]">Tales</span>
          </Link>
        </div>
        
        <nav className="hidden md:flex space-x-6 items-center">
          <a href="#how-it-works" className="text-[#1d1d1f] font-medium hover:text-[#0071e3] transition-colors duration-200">
            How it works
          </a>
          <a href="#historical-figures" className="text-[#1d1d1f] font-medium hover:text-[#0071e3] transition-colors duration-200">
            Gallery
          </a>
          <a href="#about" className="text-[#1d1d1f] font-medium hover:text-[#0071e3] transition-colors duration-200">
            About
          </a>
          <Button onClick={scrollToApp} className="apple-button">
            Get Started
          </Button>
        </nav>

        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" className="p-2 text-[#1d1d1f]">
              <i className="fas fa-bars text-xl"></i>
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[300px] p-0">
            <div className="flex flex-col py-6">
              <div className="px-6 mb-6">
                <Link href="/" className="text-2xl font-semibold text-[#1d1d1f]">
                  Time<span className="text-[#0071e3]">Tales</span>
                </Link>
              </div>
              
              <div className="flex flex-col space-y-4 px-6">
                <SheetClose asChild>
                  <a 
                    href="#how-it-works" 
                    className="text-[#1d1d1f] font-medium hover:text-[#0071e3] transition-colors duration-200 py-2"
                    onClick={() => setIsOpen(false)}
                  >
                    How it works
                  </a>
                </SheetClose>
                
                <SheetClose asChild>
                  <a 
                    href="#historical-figures" 
                    className="text-[#1d1d1f] font-medium hover:text-[#0071e3] transition-colors duration-200 py-2"
                    onClick={() => setIsOpen(false)}
                  >
                    Gallery
                  </a>
                </SheetClose>
                
                <SheetClose asChild>
                  <a 
                    href="#about" 
                    className="text-[#1d1d1f] font-medium hover:text-[#0071e3] transition-colors duration-200 py-2"
                    onClick={() => setIsOpen(false)}
                  >
                    About
                  </a>
                </SheetClose>
                
                <SheetClose asChild>
                  <Button 
                    onClick={() => {
                      setIsOpen(false);
                      setTimeout(scrollToApp, 100);
                    }} 
                    className="apple-button mt-4"
                  >
                    Get Started
                  </Button>
                </SheetClose>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
