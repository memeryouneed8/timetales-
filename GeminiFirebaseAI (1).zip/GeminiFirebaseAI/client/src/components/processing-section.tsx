import { useEffect } from "react";

interface ProcessingSectionProps {
  processingStep: number;
  setProcessingStep: (step: number) => void;
}

export function ProcessingSection({ processingStep, setProcessingStep }: ProcessingSectionProps) {
  const processingSteps = [
    'Analyzing your photo...',
    'Detecting facial features...',
    'Searching historical database...',
    'Generating your connection...'
  ];

  useEffect(() => {
    // Simulate processing steps with a timer
    const interval = setInterval(() => {
      setProcessingStep((prev) => {
        if (prev < processingSteps.length - 1) {
          return prev + 1;
        }
        clearInterval(interval);
        return prev;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [setProcessingStep, processingSteps.length]);

  return (
    <div className="flex flex-col items-center justify-center py-12">
      <div className="relative w-20 h-20 mb-6">
        <span className="absolute inset-0 rounded-full bg-[#0071e3]/10 animate-ping"></span>
        <span className="absolute inset-3 rounded-full bg-[#0071e3] animate-pulse"></span>
      </div>
      <h3 className="text-xl font-medium text-[#1d1d1f] mb-2">
        {processingSteps[processingStep]}
      </h3>
      <p className="text-[#86868b] text-center max-w-md">
        We're detecting facial features and searching for historical connections.
      </p>
    </div>
  );
}
