import { useFileUpload } from "@/lib/hooks";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

interface UploadSectionProps {
  onFileSelected: (file: File, fileUrl: string) => void;
}

export function UploadSection({ onFileSelected }: UploadSectionProps) {
  const {
    file,
    fileUrl,
    isDragging,
    fileInputRef,
    handleDragOver,
    handleDragLeave,
    handleDrop,
    handleFileChange,
    triggerFileInput,
    clearFile
  } = useFileUpload();

  const handleContinue = () => {
    if (file && fileUrl) {
      onFileSelected(file, fileUrl);
    }
  };

  return (
    <div className="mb-8">
      <h2 className="text-2xl font-semibold text-[#1d1d1f] mb-4">Upload Your Photo</h2>
      <p className="text-[#86868b] mb-6">We'll analyze your facial features to find your historical connections.</p>
      
      {!fileUrl ? (
        <div 
          className={`upload-area ${isDragging ? 'active' : ''}`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <i className="fas fa-cloud-upload-alt text-4xl text-[#86868b] mb-4"></i>
          <p className="text-[#1d1d1f] font-medium mb-2">Drag and drop your photo here</p>
          <p className="text-[#86868b] text-sm mb-4">or</p>
          <Button onClick={triggerFileInput} className="apple-button">
            Browse Files
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*"
              onChange={handleFileChange}
            />
          </Button>
          <p className="text-[#86868b] text-sm mt-4">Supported formats: JPG, PNG (max 10MB)</p>
        </div>
      ) : (
        <div className="flex flex-col items-center">
          <div className="w-full max-w-md mb-6">
            <Card className="overflow-hidden rounded-2xl">
              <div className="aspect-square relative">
                <img 
                  src={fileUrl} 
                  alt="Preview" 
                  className="w-full h-full object-cover"
                />
              </div>
            </Card>
          </div>
          <div className="flex gap-4">
            <Button onClick={clearFile} variant="outline" className="rounded-full">
              Try Different Photo
            </Button>
            <Button onClick={handleContinue} className="apple-button">
              Continue
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
