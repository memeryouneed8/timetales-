import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import { useEffect } from "react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Load face-api.js models when the app starts
  useEffect(() => {
    import("./lib/face-detection").then(({ loadModels }) => {
      loadModels().catch(err => {
        console.warn("Face detection models failed to load, app will use fallback mode", err);
        // Continue with the app anyway, we'll use fallback mode
      });
    });
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
