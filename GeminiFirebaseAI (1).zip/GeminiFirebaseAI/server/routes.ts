import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import axios from "axios";
import { 
  storyGenerationRequestSchema, 
  storyGenerationResponseSchema,
  faceDetectionSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all historical figures
  app.get("/api/historical-figures", async (req, res) => {
    try {
      const figures = await storage.getHistoricalFigures();
      res.json(figures);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch historical figures" });
    }
  });

  // Get a specific historical figure
  app.get("/api/historical-figures/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const figure = await storage.getHistoricalFigure(id);
      
      if (!figure) {
        return res.status(404).json({ message: "Historical figure not found" });
      }
      
      res.json(figure);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch historical figure" });
    }
  });

  // Generate a story connecting user with a historical figure
  app.post("/api/generate-story", async (req, res) => {
    try {
      const validatedData = storyGenerationRequestSchema.parse(req.body);
      const { faceFeatures, historicalFigureId } = validatedData;
      
      // Get historical figure - either specified or random
      let historicalFigure;
      if (historicalFigureId) {
        historicalFigure = await storage.getHistoricalFigure(historicalFigureId);
        if (!historicalFigure) {
          return res.status(404).json({ message: "Historical figure not found" });
        }
      } else {
        historicalFigure = await storage.getRandomHistoricalFigure();
      }

      // Get Gemini API key from environment variables
      const apiKey = process.env.GEMINI_API_KEY || "";
      if (!apiKey) {
        return res.status(500).json({ message: "Gemini API key not configured" });
      }

      // Create a prompt for Gemini API
      let prompt = `Generate a creative and insightful story (about 3 paragraphs) connecting the user to ${historicalFigure.name} (${historicalFigure.shortDescription}, ${historicalFigure.yearBorn}-${historicalFigure.yearDied || 'present'}). The story should:
1. Mention shared physical or personality traits based on facial analysis
2. Imagine how they might have interacted if they lived in the same time period
3. Highlight common values or approaches to life
4. Include references to ${historicalFigure.name}'s accomplishments and historical context
5. Be written in second person ("you")
6. Be inspirational and thoughtful

Some facts about ${historicalFigure.name}:
- Era: ${historicalFigure.era}
- Region: ${historicalFigure.region}
- Profession: ${historicalFigure.profession}
- Notable facts: ${JSON.stringify(historicalFigure.notableFacts)}
- Quote: "${historicalFigure.quote || 'No known quote'}"

Face analysis data: ${JSON.stringify(faceFeatures || 'No specific facial features detected')}

Format the response as paragraphs of text only, without any introductions, conclusions, or markdown formatting.`;

      let generatedText = '';
      try {
        // Call Gemini API
        console.log("Calling Gemini API...");
        const response = await axios.post(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key=${apiKey}`,
          {
            contents: [
              {
                parts: [
                  {
                    text: prompt
                  }
                ]
              }
            ],
            generationConfig: {
              temperature: 0.7,
              maxOutputTokens: 1024
            }
          }
        );

        // Extract the generated text from Gemini's response
        console.log("Gemini API response received");
        generatedText = response.data.candidates[0].content.parts[0].text;
      } catch (error: any) {
        console.error("Error calling Gemini API:", 
          error.response?.status || 'Unknown status', 
          error.response?.data || error.message || 'Unknown error');
        
        // Fallback content if API fails
        const notableFact = Array.isArray(historicalFigure.notableFacts) && historicalFigure.notableFacts.length > 0 
          ? historicalFigure.notableFacts[0] 
          : 'innovation and determination';
        
        generatedText = `The moment you looked at your historical match, ${historicalFigure.name}, something clicked. Beyond the superficial resemblance, there's a deeper connection that transcends time.

${historicalFigure.name}, known for ${historicalFigure.shortDescription}, lived during ${historicalFigure.era} in ${historicalFigure.region}. Despite the centuries between you, your shared traits are uncanny. Your analytical approach to challenges mirrors how ${historicalFigure.profession === 'Artist' ? 'they approached their canvas' : 'they approached their work'}.

If you had lived in the same era, perhaps you would have been collaborators or confidants. ${historicalFigure.name}'s legacy continues to influence the world today, and in your own way, you carry forward that same spirit of ${notableFact}.

Take inspiration from ${historicalFigure.name}'s approach to life. Try incorporating some of their practices into your routine: ${historicalFigure.profession === 'Artist' ? 'dedicate time to creative expression' : historicalFigure.profession === 'Scientist' ? 'approach problems with methodical curiosity' : 'lead with conviction and purpose in your endeavors'}.

Remember their famous words: "${historicalFigure.quote}" - Let this wisdom guide you as you forge your own path forward.`;
      }

      // Prepare and return the story response
      const storyResponse = {
        historicalFigure: {
          id: historicalFigure.id,
          name: historicalFigure.name,
          shortDescription: historicalFigure.shortDescription,
          yearBorn: historicalFigure.yearBorn,
          yearDied: historicalFigure.yearDied,
          imageUrl: historicalFigure.imageUrl,
          era: historicalFigure.era,
          quote: historicalFigure.quote
        },
        storyContent: generatedText
      };

      // Validate the response
      storyGenerationResponseSchema.parse(storyResponse);
      
      // Create a user story record in storage
      await storage.createUserStory({
        userImageUrl: "user-uploaded-image", // This would be a real URL in production
        historicalFigureId: historicalFigure.id,
        storyContent: generatedText,
        createdAt: new Date().toISOString(),
        shared: false
      });

      res.json(storyResponse);
    } catch (error) {
      console.error("Story generation error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request data", details: error.errors });
      }
      res.status(500).json({ message: "Failed to generate story" });
    }
  });

  // Share a story
  app.post("/api/stories/:id/share", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const story = await storage.getUserStory(id);
      
      if (!story) {
        return res.status(404).json({ message: "Story not found" });
      }
      
      // In a real app, this would update the story in the database
      // and potentially generate a shareable link
      
      res.json({ message: "Story shared successfully", shareableLink: `https://timetales.app/story/${id}` });
    } catch (error) {
      res.status(500).json({ message: "Failed to share story" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
