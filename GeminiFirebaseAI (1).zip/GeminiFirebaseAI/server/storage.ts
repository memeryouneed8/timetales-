import { users, type User, type InsertUser, 
  type HistoricalFigure, type InsertHistoricalFigure,
  type UserStory, type InsertUserStory } from "@shared/schema";

// Storage interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Historical Figure methods
  getHistoricalFigures(): Promise<HistoricalFigure[]>;
  getHistoricalFigure(id: number): Promise<HistoricalFigure | undefined>;
  createHistoricalFigure(figure: InsertHistoricalFigure): Promise<HistoricalFigure>;
  getRandomHistoricalFigure(): Promise<HistoricalFigure>;
  
  // User Story methods
  createUserStory(story: InsertUserStory): Promise<UserStory>;
  getUserStory(id: number): Promise<UserStory | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private historicalFigures: Map<number, HistoricalFigure>;
  private userStories: Map<number, UserStory>;
  private userCurrentId: number;
  private figureCurrentId: number;
  private storyCurrentId: number;

  constructor() {
    this.users = new Map();
    this.historicalFigures = new Map();
    this.userStories = new Map();
    this.userCurrentId = 1;
    this.figureCurrentId = 1;
    this.storyCurrentId = 1;
    
    // Initialize with historical figures
    this.initializeHistoricalFigures();
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getHistoricalFigures(): Promise<HistoricalFigure[]> {
    return Array.from(this.historicalFigures.values());
  }

  async getHistoricalFigure(id: number): Promise<HistoricalFigure | undefined> {
    return this.historicalFigures.get(id);
  }

  async createHistoricalFigure(figure: InsertHistoricalFigure): Promise<HistoricalFigure> {
    const id = this.figureCurrentId++;
    // Ensure all required fields are present with proper types
    const historicalFigure: HistoricalFigure = { 
      ...figure, 
      id,
      yearDied: figure.yearDied === undefined ? null : figure.yearDied,
      quote: figure.quote === undefined ? null : figure.quote
    };
    this.historicalFigures.set(id, historicalFigure);
    return historicalFigure;
  }

  async getRandomHistoricalFigure(): Promise<HistoricalFigure> {
    const figures = Array.from(this.historicalFigures.values());
    const randomIndex = Math.floor(Math.random() * figures.length);
    return figures[randomIndex];
  }

  async createUserStory(story: InsertUserStory): Promise<UserStory> {
    const id = this.storyCurrentId++;
    const userStory: UserStory = { 
      ...story, 
      id,
      shared: story.shared === undefined ? false : story.shared
    };
    this.userStories.set(id, userStory);
    return userStory;
  }

  async getUserStory(id: number): Promise<UserStory | undefined> {
    return this.userStories.get(id);
  }

  private initializeHistoricalFigures() {
    const historicalFiguresData: InsertHistoricalFigure[] = [
      {
        name: "Leonardo da Vinci",
        shortDescription: "Renaissance polymath",
        yearBorn: 1452,
        yearDied: 1519,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f7/Francesco_Melzi_-_Portrait_of_Leonardo_-_WGA14795.jpg/800px-Francesco_Melzi_-_Portrait_of_Leonardo_-_WGA14795.jpg",
        fullDescription: "Italian polymath of the Renaissance period, widely considered one of the greatest painters of all time. He was also a scientist, engineer, inventor, mathematician, architect, anatomist, and botanist.",
        era: "Renaissance",
        region: "Italy",
        profession: "Artist, Inventor, Polymath",
        notableFacts: ["Painted the Mona Lisa", "Designed flying machines", "Created detailed anatomical drawings"],
        quote: "Learning never exhausts the mind. Live as if you were to die tomorrow, learn as if you were to live forever."
      },
      {
        name: "Frida Kahlo",
        shortDescription: "Mexican artist",
        yearBorn: 1907,
        yearDied: 1954,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/06/Frida_Kahlo%2C_by_Guillermo_Kahlo.jpg/800px-Frida_Kahlo%2C_by_Guillermo_Kahlo.jpg",
        fullDescription: "Mexican painter known for her many portraits, self-portraits, and works inspired by the nature and artifacts of Mexico. Her art explored questions of identity, postcolonialism, gender, class, and race in Mexican society.",
        era: "20th Century",
        region: "Mexico",
        profession: "Artist",
        notableFacts: ["Known for self-portraits", "Used vibrant colors and Mexican folk art style", "Married to Diego Rivera"],
        quote: "I paint myself because I am so often alone and because I am the subject I know best. Embrace your uniqueness – it's your superpower."
      },
      {
        name: "Nikola Tesla",
        shortDescription: "Inventor and engineer",
        yearBorn: 1856,
        yearDied: 1943,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/79/Tesla_circa_1890.jpeg/800px-Tesla_circa_1890.jpeg",
        fullDescription: "Serbian-American inventor, electrical engineer, mechanical engineer, and futurist best known for his contributions to the design of the modern alternating current electricity supply system.",
        era: "19th-20th Century",
        region: "Serbia/United States",
        profession: "Inventor, Engineer",
        notableFacts: ["Invented the Tesla coil", "Pioneered alternating current", "Had photographic memory"],
        quote: "The present is theirs; the future, for which I really worked, is mine. If you want to find the secrets of the universe, think in terms of energy, frequency and vibration."
      },
      {
        name: "Queen Nefertiti",
        shortDescription: "Ancient Egyptian queen",
        yearBorn: 1370,
        yearDied: 1330,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Nofretete_Neues_Museum.jpg/800px-Nofretete_Neues_Museum.jpg",
        fullDescription: "Egyptian queen and the Great Royal Wife of Pharaoh Akhenaten. She was known for her role in the religious revolution focusing worship on the sun disk Aten. Her bust is one of the most copied works of ancient Egypt.",
        era: "Ancient Egypt",
        region: "Egypt",
        profession: "Queen",
        notableFacts: ["Known for her beauty", "Supported religious reforms", "Famous limestone bust"],
        quote: "True beauty comes from carrying yourself with dignity and grace, and from leading with wisdom and compassion."
      },
      {
        name: "Marie Curie",
        shortDescription: "Physicist and chemist",
        yearBorn: 1867,
        yearDied: 1934,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Marie_Curie_c1920.jpg/800px-Marie_Curie_c1920.jpg",
        fullDescription: "Polish and naturalized-French physicist and chemist who conducted pioneering research on radioactivity. She was the first woman to win a Nobel Prize, the first person to win Nobel Prizes in two scientific fields, and the only person to win Nobel Prizes in multiple scientific fields.",
        era: "19th-20th Century",
        region: "Poland/France",
        profession: "Physicist, Chemist",
        notableFacts: ["Discovered radium and polonium", "First woman to win Nobel Prize", "Only person to win Nobel Prize in two different sciences"],
        quote: "Nothing in life is to be feared, it is only to be understood. Now is the time to understand more, so that we may fear less."
      },
      {
        name: "Mahatma Gandhi",
        shortDescription: "Civil rights leader",
        yearBorn: 1869,
        yearDied: 1948,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Mahatma-Gandhi%2C_studio%2C_1931.jpg/800px-Mahatma-Gandhi%2C_studio%2C_1931.jpg",
        fullDescription: "Indian lawyer, anti-colonial nationalist and political ethicist who employed nonviolent resistance to lead the successful campaign for India's independence from British rule. His vision of an independent India based on religious pluralism was challenged by the partition of India and Pakistan.",
        era: "19th-20th Century",
        region: "India",
        profession: "Political Leader",
        notableFacts: ["Led India to independence", "Advocated nonviolent civil disobedience", "Known as 'Father of the Nation' in India"],
        quote: "Be the change that you wish to see in the world. Strength does not come from physical capacity. It comes from an indomitable will."
      },
      {
        name: "Ada Lovelace",
        shortDescription: "Mathematician and writer",
        yearBorn: 1815,
        yearDied: 1852,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a4/Ada_Lovelace_portrait.jpg/800px-Ada_Lovelace_portrait.jpg",
        fullDescription: "English mathematician and writer, chiefly known for her work on Charles Babbage's proposed mechanical general-purpose computer, the Analytical Engine. She was the first to recognize that the machine had applications beyond pure calculation, and published the first algorithm intended to be carried out by such a machine.",
        era: "19th Century",
        region: "England",
        profession: "Mathematician, Writer",
        notableFacts: ["First computer programmer", "Worked on Analytical Engine", "Daughter of poet Lord Byron"],
        quote: "That brain of mine is something more than merely mortal; as time will show. The more I study, the more insatiable do I feel my genius for it to be."
      },
      {
        name: "Malcolm X",
        shortDescription: "Human rights activist",
        yearBorn: 1925,
        yearDied: 1965,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Malcolm_X_NYWTS_2a.jpg/800px-Malcolm_X_NYWTS_2a.jpg",
        fullDescription: "American Muslim minister and human rights activist who was a prominent figure during the civil rights movement. A spokesman for the Nation of Islam, he was a vocal advocate for Black empowerment and the promotion of Islam within the Black community.",
        era: "20th Century",
        region: "United States",
        profession: "Activist, Minister",
        notableFacts: ["Civil rights leader", "Advocated for Black empowerment", "Changed views on racial integration later in life"],
        quote: "Education is the passport to the future, for tomorrow belongs to those who prepare for it today. If you have no critics, you'll likely have no success."
      },
      {
        name: "Cleopatra",
        shortDescription: "Egyptian ruler",
        yearBorn: 69,
        yearDied: 30,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Kleopatra-VII.-Altes-Museum-Berlin1.jpg/800px-Kleopatra-VII.-Altes-Museum-Berlin1.jpg",
        fullDescription: "Queen of the Ptolemaic Kingdom of Egypt from 51 to 30 BCE, and its last active ruler. A member of the Ptolemaic dynasty, she was a descendant of its founder Ptolemy I Soter, a Macedonian Greek general and companion of Alexander the Great.",
        era: "Ancient Egypt",
        region: "Egypt",
        profession: "Queen, Ruler",
        notableFacts: ["Last active ruler of Egypt's Ptolemaic Kingdom", "Relationship with Julius Caesar and Mark Antony", "Known for intelligence and political acumen"],
        quote: "I will not be triumphed over. For I am a queen, and I will not surrender my power to anyone."
      },
      {
        name: "Albert Einstein",
        shortDescription: "Theoretical physicist",
        yearBorn: 1879,
        yearDied: 1955,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Albert_Einstein_Head.jpg/800px-Albert_Einstein_Head.jpg",
        fullDescription: "German-born theoretical physicist who developed the theory of relativity, one of the two pillars of modern physics. His work is also known for its influence on the philosophy of science.",
        era: "19th-20th Century",
        region: "Germany/United States",
        profession: "Physicist",
        notableFacts: ["Developed theory of relativity", "E=mc²", "Nobel Prize in Physics (1921)"],
        quote: "Imagination is more important than knowledge. For knowledge is limited, whereas imagination embraces the entire world."
      },
      // Adding new historical figures - villains, comedians, and more influential people
      {
        name: "Charlie Chaplin",
        shortDescription: "Comic actor and filmmaker",
        yearBorn: 1889,
        yearDied: 1977,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/00/Charlie_Chaplin.jpg/800px-Charlie_Chaplin.jpg",
        fullDescription: "English comic actor, filmmaker, and composer who rose to fame in the era of silent film. He became a worldwide icon through his screen persona, 'The Tramp', and is considered one of the film industry's most important figures.",
        era: "20th Century",
        region: "United Kingdom/United States",
        profession: "Actor, Director, Comedian",
        notableFacts: ["Created the iconic 'Tramp' character", "Pioneered comedy in silent films", "Co-founded United Artists studio"],
        quote: "A day without laughter is a day wasted. Failure is unimportant. It takes courage to make a fool of yourself."
      },
      {
        name: "Genghis Khan",
        shortDescription: "Mongol Empire founder",
        yearBorn: 1162,
        yearDied: 1227,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/35/YuanEmperorAlbumGenghisPortrait.jpg/800px-YuanEmperorAlbumGenghisPortrait.jpg",
        fullDescription: "Founder and first Great Khan of the Mongol Empire, which became the largest contiguous empire in history after his death. After founding the Empire and being proclaimed Genghis Khan, he united many of the nomadic tribes of Northeast Asia and launched campaigns of conquest across Asia.",
        era: "Medieval Period",
        region: "Mongolia/Asia",
        profession: "Ruler, Military Leader",
        notableFacts: ["Created the largest land empire in history", "Revolutionized warfare tactics", "Established meritocracy in military ranks"],
        quote: "Not even a mighty warrior can break a frail arrow when it is multiplied and supported by its fellows. Conquering the world on horseback is easy; it is dismounting and governing that is hard."
      },
      {
        name: "Robin Williams",
        shortDescription: "Actor and comedian",
        yearBorn: 1951,
        yearDied: 2014,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/Robin_Williams_Happy_Feet_premiere.jpg/800px-Robin_Williams_Happy_Feet_premiere.jpg",
        fullDescription: "American actor and comedian known for his improvisational skills and the wide variety of characters he created on the spur of the moment. He rose to fame playing the alien Mork in the sitcom Mork & Mindy and went on to establish a career in both stand-up comedy and feature film acting.",
        era: "20th-21st Century",
        region: "United States",
        profession: "Actor, Comedian",
        notableFacts: ["Academy Award winner for Good Will Hunting", "Known for brilliant improvisation", "Voiced Genie in Disney's Aladdin"],
        quote: "You're only given a little spark of madness. You mustn't lose it. No matter what people tell you, words and ideas can change the world."
      },
      {
        name: "Amelia Earhart",
        shortDescription: "Aviation pioneer",
        yearBorn: 1897,
        yearDied: 1937,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Amelia_Earhart_standing_under_nose_of_her_Lockheed_Model_10-E_Electra%2C_small.jpg/800px-Amelia_Earhart_standing_under_nose_of_her_Lockheed_Model_10-E_Electra%2C_small.jpg",
        fullDescription: "American aviation pioneer and author who was the first female aviator to fly solo across the Atlantic Ocean. She set many other records, wrote best-selling books about her flying experiences, and was instrumental in the formation of The Ninety-Nines, an organization for female pilots.",
        era: "20th Century",
        region: "United States",
        profession: "Aviator, Author",
        notableFacts: ["First woman to fly solo across the Atlantic", "Set numerous aviation records", "Disappeared mysteriously in 1937"],
        quote: "The most difficult thing is the decision to act, the rest is merely tenacity. Never interrupt someone doing something you said couldn't be done."
      },
      {
        name: "Bruce Lee",
        shortDescription: "Martial artist and actor",
        yearBorn: 1940,
        yearDied: 1973,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Bruce_Lee_1973.jpg/800px-Bruce_Lee_1973.jpg",
        fullDescription: "Hong Kong American martial artist, actor, director, martial arts instructor and philosopher. He was the founder of Jeet Kune Do, a hybrid martial arts philosophy drawing from different combat disciplines that is often credited with paving the way for modern mixed martial arts (MMA).",
        era: "20th Century",
        region: "Hong Kong/United States",
        profession: "Martial Artist, Actor, Philosopher",
        notableFacts: ["Created Jeet Kune Do martial art", "Revolutionized martial arts films", "Bridged gap between Eastern and Western cultures"],
        quote: "Be water, my friend. Empty your mind. Be formless, shapeless, like water. You put water into a cup, it becomes the cup. You put water into a bottle, it becomes the bottle. You put it into a teapot, it becomes the teapot. Now water can flow or it can crash. Be water, my friend."
      },
      {
        name: "Marilyn Monroe",
        shortDescription: "Actress and cultural icon",
        yearBorn: 1926,
        yearDied: 1962,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Norma_Jean.jpg/800px-Norma_Jean.jpg",
        fullDescription: "American actress, model, and singer who became a major sex symbol in the 1950s and early 1960s. She starred in a number of commercially successful films and received a Golden Globe for Best Actress for her work in the film 'Some Like It Hot'.",
        era: "20th Century",
        region: "United States",
        profession: "Actress, Model, Singer",
        notableFacts: ["Major Hollywood sex symbol", "Starred in classic films like 'Some Like It Hot'", "Established her own production company"],
        quote: "Imperfection is beauty, madness is genius and it's better to be absolutely ridiculous than absolutely boring. Give a girl the right shoes, and she can conquer the world."
      },
      {
        name: "Blackbeard",
        shortDescription: "Infamous pirate",
        yearBorn: 1680,
        yearDied: 1718,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Blackbeard_the_Pirate.jpg/800px-Blackbeard_the_Pirate.jpg",
        fullDescription: "Edward Teach, better known as Blackbeard, was an English pirate who operated around the West Indies and the eastern coast of Britain's North American colonies. He is one of the most infamous and feared pirates in history, known for his intimidating appearance and fearsome reputation.",
        era: "Golden Age of Piracy",
        region: "Caribbean/Atlantic",
        profession: "Pirate Captain",
        notableFacts: ["Commanded the Queen Anne's Revenge", "Created fearsome persona by lighting fuses in his beard", "Blockaded Charleston harbor"],
        quote: "If I don't kill a man every now and then, they forget who I am. Sometimes you need to create your own fearsome reputation to avoid actual conflict."
      },
      {
        name: "Salvador Dalí",
        shortDescription: "Surrealist artist",
        yearBorn: 1904,
        yearDied: 1989,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Salvador_Dal%C3%AD_1939.jpg/800px-Salvador_Dal%C3%AD_1939.jpg",
        fullDescription: "Spanish surrealist artist renowned for his technical skill, precise draftsmanship, and the striking and bizarre images in his work. His painterly skills are often attributed to the influence of Renaissance masters. Dalí's expansive artistic repertoire included film, sculpture, and photography.",
        era: "20th Century",
        region: "Spain",
        profession: "Artist",
        notableFacts: ["Known for melting clocks in 'The Persistence of Memory'", "Collaborated with Alfred Hitchcock and Walt Disney", "Had a distinctive upturned mustache"],
        quote: "I don't do drugs. I am drugs. Have no fear of perfection – you'll never reach it. Intelligence without ambition is a bird without wings."
      },
      {
        name: "Al Capone",
        shortDescription: "American gangster",
        yearBorn: 1899,
        yearDied: 1947,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/Al_Capone_in_1930.jpg/800px-Al_Capone_in_1930.jpg",
        fullDescription: "American gangster and businessman who attained notoriety during the Prohibition era as the co-founder and boss of the Chicago Outfit. His seven-year reign as crime boss ended when he went to prison at age 33.",
        era: "Prohibition Era",
        region: "United States",
        profession: "Gangster, Businessman",
        notableFacts: ["Ran Chicago's criminal underworld during Prohibition", "Responsible for the St. Valentine's Day Massacre", "Eventually imprisoned for tax evasion"],
        quote: "You can get much further with a kind word and a gun than you can with a kind word alone. Don't mistake my kindness for weakness. I am kind to everyone, but when someone is unkind to me, weak is not what you're going to remember about me."
      },
      {
        name: "Joan of Arc",
        shortDescription: "Military leader and saint",
        yearBorn: 1412,
        yearDied: 1431,
        imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Joan_of_Arc_miniature_graded.jpg/800px-Joan_of_Arc_miniature_graded.jpg",
        fullDescription: "French heroine who played a decisive role in the Hundred Years' War. Claiming divine guidance, she led the French army to several important victories and was instrumental in having Charles VII crowned king. She was captured, tried for heresy and witchcraft, and burned at the stake when she was 19 years old.",
        era: "Medieval Period",
        region: "France",
        profession: "Military Leader",
        notableFacts: ["Led French forces at age 17", "Claimed to hear voices from saints", "Canonized as a Roman Catholic saint"],
        quote: "I am not afraid. I was born to do this. All battles are first won or lost in the mind. Act, and God will act with you."
      }
    ];

    historicalFiguresData.forEach(figure => {
      this.createHistoricalFigure(figure);
    });
  }
}

export const storage = new MemStorage();
