import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Historical Figures Schema
export const historicalFigures = pgTable("historical_figures", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  shortDescription: text("short_description").notNull(),
  yearBorn: integer("year_born").notNull(),
  yearDied: integer("year_died"),
  imageUrl: text("image_url").notNull(),
  fullDescription: text("full_description").notNull(),
  era: text("era").notNull(),
  region: text("region").notNull(),
  profession: text("profession").notNull(),
  notableFacts: jsonb("notable_facts").notNull(),
  quote: text("quote"),
});

export const insertHistoricalFigureSchema = createInsertSchema(historicalFigures).omit({
  id: true,
});

export type InsertHistoricalFigure = z.infer<typeof insertHistoricalFigureSchema>;
export type HistoricalFigure = typeof historicalFigures.$inferSelect;

// User Stories Schema
export const userStories = pgTable("user_stories", {
  id: serial("id").primaryKey(),
  userImageUrl: text("user_image_url").notNull(),
  historicalFigureId: integer("historical_figure_id").notNull(),
  storyContent: text("story_content").notNull(),
  createdAt: text("created_at").notNull(),
  shared: boolean("shared").default(false),
});

export const insertUserStorySchema = createInsertSchema(userStories).omit({
  id: true,
});

export type InsertUserStory = z.infer<typeof insertUserStorySchema>;
export type UserStory = typeof userStories.$inferSelect;

// Face Detection Results Schema
export const faceDetectionSchema = z.object({
  faceFeatures: z.record(z.any()).optional(),
  imageData: z.string(),
});

export type FaceDetectionResult = z.infer<typeof faceDetectionSchema>;

// Story Generation Request Schema
export const storyGenerationRequestSchema = z.object({
  faceFeatures: z.record(z.any()).optional(),
  historicalFigureId: z.number().optional(),
});

export type StoryGenerationRequest = z.infer<typeof storyGenerationRequestSchema>;

// Story Generation Response Schema
export const storyGenerationResponseSchema = z.object({
  historicalFigure: z.object({
    id: z.number(),
    name: z.string(),
    shortDescription: z.string(),
    yearBorn: z.number(),
    yearDied: z.number().optional(),
    imageUrl: z.string(),
    era: z.string(),
    quote: z.string().optional(),
  }),
  storyContent: z.string(),
});

export type StoryGenerationResponse = z.infer<typeof storyGenerationResponseSchema>;
